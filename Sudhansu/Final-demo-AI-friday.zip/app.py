
import streamlit as st
import pandas as pd
import plotly.express as px

from utils.helpers import enrich_portfolio_data
from services.analytics_service import generate_portfolio_analytics
from services.risk_service import calculate_risk_analysis
from services.ai_service import generate_ai_insights
from services.chat_service import portfolio_chat
from services.summary_service import generate_dataset_summary

st.set_page_config(page_title="FINsight- Intelligent Portfolio Analysis", page_icon="💰", layout="wide")

st.title("💰 FINsight- Intelligent Portfolio Analysis")
st.markdown("AI-powered multi-asset portfolio analyzer with Portfolio Chat Assistant")

if "messages" not in st.session_state:
    st.session_state.messages = []

left_col, right_col = st.columns([3, 1])

with st.sidebar:
    st.header("Portfolio Configuration")
    risk_appetite = st.selectbox("Risk Appetite", ["Conservative", "Moderate", "Aggressive"])
    uploaded_file = st.file_uploader("Upload Portfolio CSV", type=["csv"])

if uploaded_file:
    with st.spinner("Analyzing portfolio..."):
        df = pd.read_csv(uploaded_file)

        dataset_summary = generate_dataset_summary(df)
        st.session_state["dataset_summary"] = dataset_summary

        df = enrich_portfolio_data(df)
        analytics = generate_portfolio_analytics(df)
        risk_analysis = calculate_risk_analysis(df, risk_appetite)
        ai_insights = generate_ai_insights(risk_appetite, analytics, risk_analysis, df)

        st.session_state["portfolio_df"] = df
        st.session_state["analytics"] = analytics
        st.session_state["risk_analysis"] = risk_analysis
        st.session_state["ai_insights"] = ai_insights
        st.session_state["analysis_complete"] = True

    with left_col:
        st.success("Portfolio analysis completed!")

        col1, col2, col3, col4 = st.columns(4)
        col1.metric("Total Investment", f"₹{analytics['total_investment']:,.2f}")
        col2.metric("Current Value", f"₹{analytics['total_current_value']:,.2f}")
        col3.metric("Profit / Loss", f"₹{analytics['total_profit_loss']:,.2f}")
        col4.metric("ROI %", f"{analytics['roi_percentage']}%")

        st.subheader("Portfolio Holdings")
        st.dataframe(df, use_container_width=True)

        c1, c2 = st.columns(2)

        with c1:
            fig1 = px.pie(
                analytics["asset_allocation"],
                names="AssetType",
                values="CurrentValue"
            )
            st.plotly_chart(fig1, use_container_width=True)

        with c2:
            fig2 = px.bar(df, x="Name", y="ProfitLoss", color="AssetType")
            st.plotly_chart(fig2, use_container_width=True)

        st.subheader("Risk Exposure")
        st.metric("Risk Level", risk_analysis["risk_level"])

        for msg in risk_analysis["risk_messages"]:
            st.warning(msg)

        st.subheader("AI Investment Insights")
        st.write(ai_insights)

        # st.subheader("📄 Dataset Summary")
        # st.markdown(st.session_state.get("dataset_summary", "No summary available"))

        st.subheader("🎯 Analytical Investment Suggestions")
        allocation = analytics["asset_allocation"]
        top_assets = allocation.sort_values("CurrentValue", ascending=False)

        if len(top_assets) > 0:
            dominant_asset = top_assets.iloc[0]["AssetType"]
            st.info(
                f"Current portfolio is heavily tilted towards {dominant_asset}. "
                "Consider increasing exposure to underrepresented asset classes for diversification."
            )

        if analytics["roi_percentage"] > 0:
            st.success(
                "Portfolio is generating positive returns. Consider adding capital gradually "
                "to the best-performing diversified asset classes."
            )
        else:
            st.warning(
                "Portfolio returns are currently weak. Rebalance low-performing holdings and "
                "increase diversification."
            )

with right_col:
    st.subheader("💬 Portfolio Chat")

    if st.session_state.get("analysis_complete", False):

        for message in st.session_state.messages:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])

        prompt = st.chat_input("Ask about your portfolio...")

        if prompt:
            st.session_state.messages.append(
                {"role": "user", "content": prompt}
            )

            with st.chat_message("user"):
                st.markdown(prompt)

            response = portfolio_chat(
                question=prompt,
                portfolio_df=st.session_state["portfolio_df"],
                analytics=st.session_state["analytics"],
                risk_analysis=st.session_state["risk_analysis"],
                ai_insights=st.session_state["ai_insights"],
                chat_history=st.session_state.messages[:-1]
            )

            st.session_state.messages.append(
                {"role": "assistant", "content": response}
            )

            with st.chat_message("assistant"):
                st.markdown(response)
    else:
        st.info("Generate portfolio analysis to enable chat.")
