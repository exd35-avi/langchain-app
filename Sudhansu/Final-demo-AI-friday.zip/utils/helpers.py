
from services.market_service import get_market_data


def enrich_portfolio_data(df):

    market_prices = []

    for _, row in df.iterrows():

        asset_type = row["AssetType"]
        symbol = row["Symbol"]

        market_data = get_market_data(
            symbol,
            asset_type
        )

        api_price = market_data.get("current_price")

        if api_price and api_price > 0:
            market_prices.append(api_price)
        else:
            market_prices.append(
                row["CurrentMarketPrice"]
            )

    df["FinalMarketPrice"] = market_prices

    df["InvestedAmount"] = (
        df["Quantity"] * df["PurchasePrice"]
    )

    df["CurrentValue"] = (
        df["Quantity"] * df["FinalMarketPrice"]
    )

    df["ProfitLoss"] = (
        df["CurrentValue"] - df["InvestedAmount"]
    )

    return df
