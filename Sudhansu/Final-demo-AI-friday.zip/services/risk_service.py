import pandas as pd


def calculate_risk_analysis(df, risk_appetite):

    risk_rows = []

    total_value = df["CurrentValue"].sum()

    for _, row in df.iterrows():

        allocation_pct = (
            row["CurrentValue"] / total_value
        ) * 100

        asset_type = row["AssetType"]

        base_risk = {
            "Equity": 80,
            "MutualFund": 50,
            "Gold": 35,
            "FD": 10,
            "Bond": 15
        }.get(asset_type, 50)

        concentration_risk = min(
            allocation_pct * 0.5,
            20
        )

        risk_score = min(
            base_risk + concentration_risk,
            100
        )

        if risk_score >= 70:
            risk_level = "High"
        elif risk_score >= 40:
            risk_level = "Medium"
        else:
            risk_level = "Low"

        risk_rows.append(
            {
                "Name": row["Name"],
                "AssetType": asset_type,
                "CurrentValue": round(
                    row["CurrentValue"], 2
                ),
                "AllocationPct": round(
                    allocation_pct, 2
                ),
                "RiskScore": round(
                    risk_score, 2
                ),
                "RiskLevel": risk_level
            }
        )

    risk_df = pd.DataFrame(risk_rows)

    portfolio_risk_score = round(
        risk_df["RiskScore"].mean(),
        2
    )

    if portfolio_risk_score >= 70:
        portfolio_risk_level = "High"
    elif portfolio_risk_score >= 40:
        portfolio_risk_level = "Medium"
    else:
        portfolio_risk_level = "Low"

    return {

        # NEW MODEL
        "portfolio_risk_score": portfolio_risk_score,
        "portfolio_risk_level": portfolio_risk_level,
        "risk_breakdown": risk_df,

        # BACKWARD COMPATIBILITY
        "risk_score": portfolio_risk_score,
        "risk_level": portfolio_risk_level,
        "risk_messages": [],
        "investment_approach": portfolio_risk_level
    }