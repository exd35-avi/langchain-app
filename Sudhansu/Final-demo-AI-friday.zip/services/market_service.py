
import os
import requests
from dotenv import load_dotenv

load_dotenv()

API_KEY = os.getenv("ALPHA_VANTAGE_API_KEY")


def get_market_data(symbol, asset_type):

    try:

        if asset_type in ["Equity", "MutualFund"]:

            url = (
                f"https://www.alphavantage.co/query?"
                f"function=GLOBAL_QUOTE&symbol={symbol}&apikey={API_KEY}"
            )

            response = requests.get(url)
            data = response.json()

            quote = data.get("Global Quote", {})

            current_price = float(
                quote.get("05. price", 0)
            )

            return {
                "current_price": current_price
            }

        return {
            "current_price": None
        }

    except Exception as e:

        print(f"Market API error: {e}")

        return {
            "current_price": None
        }
