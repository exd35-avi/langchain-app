import os
import pandas as pd
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)


def generate_dataset_summary(df):

    sample_data = df.head(20).to_string(index=False)

    columns = ", ".join(df.columns)

    prompt = f"""
You are a data analyst.

Analyze the uploaded CSV dataset.

Dataset Columns:
{columns}

Sample Data:
{sample_data}

Generate:

1. Dataset Overview
2. Key Columns
3. Important Patterns
4. Data Quality Issues
5. Business Insights

Write in natural language.
Avoid technical jargon.
"""

    try:

        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert business analyst."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.3
        )

        return response.choices[0].message.content

    except Exception:

        return f"""
Dataset contains {len(df)} records and {len(df.columns)} columns.

Columns:
{", ".join(df.columns)}

The uploaded data appears ready for analysis.
"""