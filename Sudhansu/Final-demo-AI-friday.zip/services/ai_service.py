import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))


def generate_ai_insights(
    risk_appetite,
    analytics,
    risk_analysis,
    df
):

    portfolio_risk_score = risk_analysis.get(
        "portfolio_risk_score",
        risk_analysis.get("risk_score", "N/A")
    )

    portfolio_risk_level = risk_analysis.get(
        "portfolio_risk_level",
        risk_analysis.get("risk_level", "Unknown")
    )

    if "risk_breakdown" in risk_analysis:
        risk_table = (
            risk_analysis["risk_breakdown"]
            .sort_values(by="RiskScore", ascending=False)
            .to_string(index=False)
        )
    else:
        risk_table = "Risk breakdown unavailable"

    holdings_table = df.to_string(index=False)

    prompt = f"""
You are a senior wealth advisor and portfolio risk analyst.

Analyze the portfolio using ONLY the supplied data.

Risk Appetite:
{risk_appetite}

Portfolio Analytics:
{analytics}

Portfolio Risk Score:
{portfolio_risk_score}

Portfolio Risk Level:
{portfolio_risk_level}

Asset Wise Risk Breakdown:
{risk_table}

Portfolio Holdings:
{holdings_table}

Provide:
1. Executive Summary
2. Portfolio Risk Assessment
3. Highest Risk Holdings
4. Concentration Risk Analysis
5. Diversification Analysis
6. Asset Allocation Review
7. Personalized Recommendations

Recommendations MUST be based on actual portfolio data.
Mention asset names, allocations and risk scores where relevant.
Do not provide generic recommendations.
"""

    try:
        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {
                    "role": "system",
                    "content": "You are an expert portfolio advisor. Use only supplied portfolio data and provide personalized recommendations."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.3
        )

        return response.choices[0].message.content

    except Exception as e:

        print(f"OpenAI Error: {e}")

        recommendations = []

        if "risk_breakdown" in risk_analysis:

            risk_df = risk_analysis["risk_breakdown"]

            high_risk_assets = risk_df[risk_df["RiskLevel"] == "High"]

            if not high_risk_assets.empty:
                recommendations.append(
                    "High-risk holdings: " +
                    ", ".join(high_risk_assets["Name"].tolist())
                )

            concentrated_assets = risk_df[risk_df["AllocationPct"] > 20]

            if not concentrated_assets.empty:
                recommendations.append(
                    "Concentration risk detected in: " +
                    ", ".join(concentrated_assets["Name"].tolist())
                )

        return f"""
# AI Portfolio Insights

## Portfolio Risk Summary

Risk Score: {portfolio_risk_score}

Risk Level: {portfolio_risk_level}

## Asset Wise Risk Breakdown

{risk_table}

## Dynamic Recommendations

{chr(10).join([f"- {r}" for r in recommendations])}
"""