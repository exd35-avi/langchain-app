import os
import traceback
import httpx

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI
from langchain_core.messages import (
    SystemMessage,
    HumanMessage,
    AIMessage
)

load_dotenv()

# ----------------------------------------------------
# LLM Configuration
# ----------------------------------------------------

http_client = httpx.Client(
    verify=False,  # Keep False only if corporate SSL blocks requests
    timeout=60.0
)

llm = ChatOpenAI(
    base_url="https://genailab.tcs.in",
    model="azure_ai/genailab-maas-DeepSeek-V3-0324",
    api_key=os.getenv("OPENAI_API_KEY"),
    http_client=http_client,
    temperature=0.1
)

# ----------------------------------------------------
# Chat Function
# ----------------------------------------------------

def portfolio_chat(
    question,
    portfolio_df,
    analytics,
    risk_analysis,
    ai_insights,
    chat_history=None
):

    try:

        if chat_history is None:
            chat_history = []

        question = str(question).strip()

        if not question:
            return "Please enter a valid question."

        q = question.lower()

        total_value = float(
            portfolio_df["CurrentValue"].sum()
        )

        # ----------------------------------------
        # Deterministic Answers
        # ----------------------------------------

        if "roi" in q:
            return (
                f"Portfolio ROI is "
                f"{analytics.get('roi_percentage', 0):.2f}%"
            )

        if "profit" in q or "loss" in q:

            pnl = analytics.get(
                "total_profit_loss",
                analytics.get("profit_loss", 0)
            )

            return (
                f"Current Profit/Loss is "
                f"₹{pnl:,.2f}"
            )

        if (
            "exposure" in q
            or "allocation" in q
            or "percentage" in q
        ):

            for asset in portfolio_df["AssetType"].unique():

                if asset.lower() in q:

                    value = portfolio_df[
                        portfolio_df["AssetType"] == asset
                    ]["CurrentValue"].sum()

                    exposure = round(
                        (value / total_value) * 100,
                        2
                    )

                    return (
                        f"Your exposure in "
                        f"{asset} is "
                        f"{exposure}% of the portfolio."
                    )

        if (
            "portfolio value" in q
            or "current value" in q
            or "total value" in q
        ):
            return (
                f"Current portfolio value is "
                f"₹{total_value:,.2f}"
            )

        # ----------------------------------------
        # Risk Breakdown
        # ----------------------------------------

        risk_breakdown = ""

        if isinstance(risk_analysis, dict):

            rb = risk_analysis.get("risk_breakdown")

            if rb is not None and hasattr(rb, "to_string"):
                risk_breakdown = rb.to_string(index=False)

        # ----------------------------------------
        # Portfolio Context
        # ----------------------------------------

        context = f"""
PORTFOLIO HOLDINGS
{portfolio_df.to_string(index=False)}

PORTFOLIO ANALYTICS
{analytics}

RISK ANALYSIS
{risk_analysis}

RISK BREAKDOWN
{risk_breakdown}

AI INSIGHTS
{ai_insights}
"""

        # ----------------------------------------
        # LangChain Messages
        # ----------------------------------------

        lc_messages = []

        lc_messages.append(
            SystemMessage(
                content=f"""
You are an expert portfolio advisor.

RULES:

1. Use portfolio data first.
2. Never invent values.
3. Use previous conversation history.
4. If data is unavailable, say so.
5. Provide concise answers.

PORTFOLIO CONTEXT:

{context}
"""
            )
        )

        if len(chat_history) > 20:
            chat_history = chat_history[-20:]

        for msg in chat_history:

            role = msg.get("role")
            content = msg.get("content")

            if role == "user":
                lc_messages.append(
                    HumanMessage(content=content)
                )

            elif role == "assistant":
                lc_messages.append(
                    AIMessage(content=content)
                )

        lc_messages.append(
            HumanMessage(content=question)
        )

        # ----------------------------------------
        # LLM Call
        # ----------------------------------------

        response = llm.invoke(lc_messages)

        answer = response.content

        return answer

    except Exception as e:

        return (
            f"Chat Service Error:\n\n"
            f"{str(e)}\n\n"
            f"{traceback.format_exc()}"
        )