
def generate_portfolio_analytics(df):

    total_investment = df["InvestedAmount"].sum()

    total_current_value = df["CurrentValue"].sum()

    total_profit_loss = (
        total_current_value - total_investment
    )

    roi_percentage = (
        (total_profit_loss / total_investment) * 100
        if total_investment > 0
        else 0
    )

    asset_allocation = (
        df.groupby("AssetType")["CurrentValue"]
        .sum()
        .reset_index()
    )

    return {
        "total_investment": round(total_investment, 2),
        "total_current_value": round(total_current_value, 2),
        "total_profit_loss": round(total_profit_loss, 2),
        "roi_percentage": round(roi_percentage, 2),
        "asset_allocation": asset_allocation
    }
