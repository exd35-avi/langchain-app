
import streamlit as st
import pandas as pd
import plotly.express as px

from utils.helpers import enrich_portfolio_data

from services.analytics_service import (
    generate_portfolio_analytics
)

from services.risk_service import (
    calculate_risk_analysis
)

from services.ai_service import (
    generate_ai_insights
)

st.set_page_config(
    page_title="AI Wealth Intelligence Platform",
    page_icon="💰",
    layout="wide"
)

st.title("💰 AI Wealth Intelligence Platform")

st.markdown(
    "AI-powered multi-asset portfolio analyzer."
)

st.sidebar.header("Portfolio Configuration")

risk_appetite = st.sidebar.selectbox(
    "Risk Appetite",
    ["Conservative", "Moderate", "Aggressive"]
)

uploaded_file = st.sidebar.file_uploader(
    "Upload Portfolio CSV",
    type=["csv"]
)

if uploaded_file:

    with st.spinner("Analyzing portfolio..."):

        df = pd.read_csv(uploaded_file)

        df = enrich_portfolio_data(df)

        analytics = generate_portfolio_analytics(df)

        risk_analysis = calculate_risk_analysis(
            df,
            risk_appetite
        )

        ai_insights = generate_ai_insights(
            risk_appetite,
            analytics,
            risk_analysis,
            df
        )

    st.success("Portfolio analysis completed!")

    st.subheader("Performance Metrics")

    col1, col2, col3, col4 = st.columns(4)

    col1.metric(
        "Total Investment",
        f"₹{analytics['total_investment']:,.2f}"
    )

    col2.metric(
        "Current Value",
        f"₹{analytics['total_current_value']:,.2f}"
    )

    col3.metric(
        "Profit / Loss",
        f"₹{analytics['total_profit_loss']:,.2f}"
    )

    col4.metric(
        "ROI %",
        f"{analytics['roi_percentage']}%"
    )

    st.divider()

    st.subheader("Portfolio Holdings")

    st.dataframe(df)

    st.divider()

    col5, col6 = st.columns(2)

    with col5:

        st.subheader("Asset Allocation")

        fig1 = px.pie(
            analytics["asset_allocation"],
            names="AssetType",
            values="CurrentValue",
            title="Asset Allocation"
        )

        st.plotly_chart(
            fig1,
            use_container_width=True
        )

    with col6:

        st.subheader("Profit / Loss Distribution")

        fig2 = px.bar(
            df,
            x="Name",
            y="ProfitLoss",
            color="AssetType"
        )

        st.plotly_chart(
            fig2,
            use_container_width=True
        )

    st.divider()

    st.subheader("Risk Exposure")

    st.metric(
        "Risk Level",
        risk_analysis["risk_level"]
    )

    st.metric(
        "Investment Approach",
        risk_analysis["investment_approach"]
    )

    for msg in risk_analysis["risk_messages"]:
        st.warning(msg)

    st.divider()

    st.subheader("AI Investment Insights")

    st.write(ai_insights)

else:

    st.info(
        "Upload a portfolio CSV file to start analysis."
    )
