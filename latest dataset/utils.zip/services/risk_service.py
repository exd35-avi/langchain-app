
def calculate_risk_analysis(df, risk_appetite):

    total_value = df["CurrentValue"].sum()

    allocation = (
        df.groupby("AssetType")["CurrentValue"]
        .sum() / total_value
    ) * 100

    equity_exposure = allocation.get("Equity", 0)
    fd_exposure = allocation.get("FD", 0)
    gold_exposure = allocation.get("Gold", 0)

    risk_score = 0
    risk_messages = []

    if equity_exposure > 70:
        risk_score += 40
        risk_messages.append(
            "High equity exposure detected."
        )

    if fd_exposure + gold_exposure > 40:
        risk_messages.append(
            "Portfolio contains stable defensive assets."
        )

    if risk_appetite == "Conservative" and equity_exposure > 60:
        risk_messages.append(
            "Portfolio risk exceeds conservative appetite."
        )
        risk_score += 20

    if risk_score <= 30:
        risk_level = "Low"
    elif risk_score <= 60:
        risk_level = "Moderate"
    else:
        risk_level = "High"

    if equity_exposure > 60:
        investment_approach = (
            "Growth-Oriented Aggressive Investing"
        )
    elif fd_exposure + gold_exposure > 50:
        investment_approach = (
            "Conservative Wealth Preservation"
        )
    else:
        investment_approach = (
            "Balanced Diversified Investing"
        )

    return {
        "risk_score": risk_score,
        "risk_level": risk_level,
        "risk_messages": risk_messages,
        "investment_approach": investment_approach
    }
