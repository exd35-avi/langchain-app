
import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def portfolio_chat(question, portfolio_df, analytics, risk_analysis, ai_insights, chat_history):

    context = f'''
Portfolio Holdings:
{portfolio_df.to_string(index=False)}

Analytics:
{analytics}

Risk Analysis:
{risk_analysis}

AI Insights:
{ai_insights}
'''

    messages = [
        {
            "role": "system",
            "content": f'''You are a professional wealth advisor.

Use portfolio context whenever relevant.
If the question is unrelated to the portfolio, answer as a normal AI assistant.
Never invent portfolio values.
Portfolio Context:
{context}
'''
        }
    ]

    messages.extend(chat_history)
    messages.append({"role": "user", "content": question})

    response = client.chat.completions.create(
        model="gpt-4.1-mini",
        messages=messages,
        temperature=0.3
    )

    return response.choices[0].message.content
