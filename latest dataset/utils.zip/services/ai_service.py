import os
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

client = OpenAI(
    api_key=os.getenv("OPENAI_API_KEY")
)


def generate_ai_insights(
    risk_appetite,
    analytics,
    risk_analysis,
    df
):

    prompt = f"""
    You are a professional wealth advisor.

    Analyze this portfolio.

    Risk Appetite:
    {risk_appetite}

    Portfolio Analytics:
    {analytics}

    Risk Analysis:
    {risk_analysis}

    Holdings:
    {df.to_string(index=False)}

    Generate:
    1. Risk Exposure
    2. Investment Approach
    3. Performance Analysis
    4. Asset Allocation Insights
    5. Recommendations
    """

    try:

        response = client.chat.completions.create(
            model="gpt-4.1-mini",
            messages=[
                {
                    "role": "system",
                    "content": "You are an AI wealth advisor."
                },
                {
                    "role": "user",
                    "content": prompt
                }
            ],
            temperature=0.5
        )

        return response.choices[0].message.content

    except Exception as e:

        print(f"OpenAI Error: {e}")

        # Fallback AI summary
        return f"""
# AI Portfolio Insights

## Risk Exposure
Your portfolio risk level is:
{risk_analysis['risk_level']}

## Investment Approach
Current investment strategy:
{risk_analysis['investment_approach']}

## Portfolio Performance
Total Investment:
₹{analytics['total_investment']}

Current Value:
₹{analytics['total_current_value']}

ROI:
{analytics['roi_percentage']}%

## Recommendations
- Improve diversification
- Balance risky and defensive assets
- Align allocation with risk appetite
"""